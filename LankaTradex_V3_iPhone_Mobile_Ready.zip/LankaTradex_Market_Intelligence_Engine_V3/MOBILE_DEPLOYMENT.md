# Lanka Tradex — iPhone Deployment Checklist

## Recommended architecture

PC/local development -> GitHub repository -> Streamlit Community Cloud -> iPhone Safari -> Add to Home Screen

## Files required

- `app.py`
- `requirements.txt`
- `.streamlit/config.toml`
- `README.md`

## Deployment entrypoint

`app.py`

## First mobile test

Before cloud deployment, run:

```text
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Then test the page in a narrow browser window. After cloud deployment, open the public/private Streamlit URL on an iPhone.

## Data note

The dashboard still uses the existing V3 public-data architecture. Cloud deployment does not turn delayed/public market data into licensed real-time exchange data.
