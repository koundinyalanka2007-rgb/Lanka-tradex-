
# Lanka Tradex V3 — Production Roadmap

## Layer 1: Data
NSE/BSE licensed real-time + historical data, index constituents, derivatives/options,
FII/DII, corporate actions, RBI/economic data, global market feeds and licensed news.

## Layer 2: Storage
PostgreSQL for historical data and audit trails; Redis for low-latency cache.

## Layer 3: Feature Store
Normalize timestamps, corporate actions, missing data, outliers and market holidays.
Create point-in-time features to prevent look-ahead bias.

## Layer 4: Intelligence
Trend, momentum, breadth, macro, FX, commodities, rates, derivatives, sector rotation,
news/event classification and market-regime detection.

## Layer 5: Scoring
Separate Nifty and Bank Nifty models. Store every component score, weight, input timestamp,
model version and final score so every historical signal is auditable.

## Layer 6: Backtesting
Walk-forward testing, transaction-cost assumptions, slippage, turnover, drawdown,
hit rate, precision/recall for regimes, calibration and out-of-sample validation.

## Layer 7: API
FastAPI service exposing market state, scores, factors, explanations and historical scores.

## Layer 8: Products
Web terminal, Android app, internal research console and notification service.

## Layer 9: Governance
Versioned models, human review for published research, disclosures, conflict-of-interest
controls, audit logs and legal/compliance review before commercial securities research.
