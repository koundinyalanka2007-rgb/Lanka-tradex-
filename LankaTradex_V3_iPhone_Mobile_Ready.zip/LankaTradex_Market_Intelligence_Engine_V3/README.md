# Lanka Tradex Market Intelligence Engine V3 — Mobile Edition

This edition keeps the V3 market-intelligence engine and adds an iPhone/mobile presentation layer.

## What changed for iPhone

- Responsive Streamlit layout for phone screens.
- Sidebar starts collapsed, so the main dashboard opens cleanly on iPhone.
- Compact metric cards and typography.
- Three mobile-friendly sections: **Dashboard**, **Intelligence**, and **Charts & History**.
- Large tables remain available but are kept inside the relevant section instead of occupying the initial screen.
- Global market snapshot is reduced to the most useful columns, with tickers available in an expandable section.
- Charts remain available; landscape orientation is recommended for detailed chart inspection.
- Added a Streamlit theme/configuration for a darker fintech-style presentation.

## Run on Windows

```text
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open the local URL Streamlit prints, normally:

```text
http://localhost:8501
```

## Make it accessible on iPhone from anywhere

A local `localhost` URL is only available on the computer running Streamlit. For iPhone access from anywhere, deploy this project to a cloud host.

### Streamlit Community Cloud

1. Create/sign in to a GitHub account.
2. Create a repository and upload the contents of this project.
3. Go to Streamlit Community Cloud.
4. Create an app and select the GitHub repository.
5. Select `app.py` as the entrypoint.
6. Deploy.
7. Open the generated `*.streamlit.app` URL on the iPhone.

For production/commercial use, use appropriately licensed market data and review the applicable data-distribution and financial-regulatory requirements.

## iPhone home-screen shortcut

After the cloud URL works in Safari:

1. Open the Lanka Tradex URL.
2. Tap the Safari **Share** button.
3. Choose **Add to Home Screen**.
4. Launch Lanka Tradex from the new Home Screen icon.

This is a web app shortcut, not a native iOS App Store application.

## Important

The score is a research heuristic. It is not a guaranteed prediction or personalized investment advice. The prototype uses public Yahoo Finance data and manual research inputs. A commercial service should use appropriately licensed data feeds, persistent storage, authentication, audit logs, monitoring, and qualified adult/legal/compliance review.
